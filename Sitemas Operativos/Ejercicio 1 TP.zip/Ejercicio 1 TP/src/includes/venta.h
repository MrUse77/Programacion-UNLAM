#ifndef FILE_H
#define FILE_H

#define MAX_VENTAS 50
#define DIAS 30

typedef struct {
  int id;                 // Identificador de venta
  double monto;           // Monto de la venta
  double montoModificado; // Monto de la venta

} Venta;

typedef struct {
  Venta *ventas;
  int numVentas;
  float total;
} Dia;

int crearVentas(Venta *venta);
Dia *crearMes(int shmid, int shmid_ventas);

#endif // !#ifndef FILE_H
